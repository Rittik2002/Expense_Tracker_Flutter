import 'package:flutter/material.dart';

class city extends StatelessWidget {
   city({super.key});
  @override
  Widget build(BuildContext context) {
    return Scaffold();
  }
}